# -*- coding: UTF-8 -*-
__author__ = 'mcxiaoke'

from distutils.core import setup

setup(name='mth',
      version='1.0.0',
      description='a simple math util to calculate square of two numbers',
      author='mcxiaoke',
      author_email='mcxiaoke@python.org',
      url='http://github.com/mcxiaoke',
      py_modules=['mth']

)